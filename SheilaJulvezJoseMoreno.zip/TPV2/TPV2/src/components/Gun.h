//#pragma once
//#include "../ecs/Component.h"
//#include "../sdlutils/InputHandler.h"
//#include "../sdlutils/SDLUtils.h"
//#include "../components/Transform.h"
//#include "../utils/checkML.h"
//struct Gun:public Component
//{
//public:
//	Gun();
//	virtual~Gun();
//	void initComponent();
//	void HandleEvent(SDL_Event event);
//	void update();
//	bool getshot()const {
//		return shoot;
//	}
//	void setshot() {
//		shoot = false;
//	}
//private:
//	Transform* trans;
//	float totaltime, start, frames;
//	bool shoot = false;
//	SoundEffect* fire = &SDLUtils::instance()->soundEffects().at("fire");
//
//
//};
//
