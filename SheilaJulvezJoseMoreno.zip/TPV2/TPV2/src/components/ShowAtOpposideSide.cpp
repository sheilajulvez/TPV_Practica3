//#include "ShowAtOpposideSide.h"
//#include "../ecs/Entity.h"
//#include "../game/Game.h"
//ShowAtOpposideSide::ShowAtOpposideSide() {
//
//}
//ShowAtOpposideSide::~ShowAtOpposideSide() {
//
//}
//void ShowAtOpposideSide::initComponent() {
//	trans = ent_->getComponent<Transform>(_TRANSFORM_H_);
//}
//void ShowAtOpposideSide::update() {
//
//	if (trans->getPos().getX() > (WIN_WIDTH + trans->getW())) {
//		trans->setPos({ 0,trans->getPos().getY() });
//	}
//	else if (trans->getPos().getX() + trans->getW() < 0) {
//		trans->setPos({ WIN_WIDTH,trans->getPos().getY() });
//
//	}
//	if (trans->getPos().getY() > (WIN_HEIGHT + trans->getH())) {
//		trans->setPos({ trans->getPos().getX(), 0 });
//	}
//	else if(trans->getPos().getY() + trans->getH() < 0){
//		trans->setPos({ trans->getPos().getX(), WIN_HEIGHT });
//	}

//}
