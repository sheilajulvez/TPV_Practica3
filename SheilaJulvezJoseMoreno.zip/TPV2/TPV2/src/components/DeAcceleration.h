//#pragma once
//#include "../ecs/Component.h"
//#include "Transform.h"
//#include "../game/ecs_defs.h"
//#include "../utils/checkML.h"
//struct DeAcceleration :public Component {
//private:
//	float deacceleration = 0.995;
//	float min = 0.005;
//	Transform* trans;
//
//
//public:
//	DeAcceleration();
//	virtual ~DeAcceleration();
//	void initComponent();
//	void update();
//
//
//
//};