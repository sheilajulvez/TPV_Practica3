//#pragma once
//#include "../ecs/Component.h"
//#include "../sdlutils/SDLUtils.h"
//#include "Transform.h"
//#include "../game/ecs_defs.h"
//#include "../utils/checkML.h"
//
//struct Image :public Component {
//private:
//	Texture* texture = nullptr;
//	Transform* trans = nullptr;
//public:
//	Image(Texture* t);
//	virtual ~Image();
//	virtual void initComponent();
//	virtual  void render();
//
//
//
//};