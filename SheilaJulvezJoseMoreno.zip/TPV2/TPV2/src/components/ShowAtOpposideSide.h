//#pragma once
//#include "../ecs/Component.h"
//#include "Transform.h"
//#include "../utils/checkML.h"
//struct ShowAtOpposideSide :public Component {
//public: 
//	ShowAtOpposideSide();
//	virtual ~ShowAtOpposideSide();
//	void initComponent();
//	void update();
//private:
//	Transform* trans;
//};