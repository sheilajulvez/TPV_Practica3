//#pragma once
//#include "../ecs/Component.h"
//#include "../ecs/Entity.h"
//#include "Transform.h"
//#include "../game/ecs_defs.h"
//#include "../sdlutils/SDLUtils.h"
//#include "../utils/checkML.h"
//struct Follow:public Component
//{
//public:
//	Follow(Entity * p);
//	virtual~Follow();
//	virtual void initComponent();
//	void update();
//private:
//	Entity* player;
//	Transform* trans;
//	Transform* trans_player;
//	float totaltime=0, start=0, frames=50;
//	int frequency = 50;
//
//
//};
//
